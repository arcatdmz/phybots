Phybots - a toolkit for making robotic things
Copyright (C) 2009-2013 Jun Kato

version 1.0.1
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

"Phybots" is a Java toolkit to prototype "robotic things."

This library is distributed under MPL 1.1/GPL 2.0/LGPL 2.1
triple license. Please read LICENSE.txt for the detail.
You can get the source code by visiting its official site.

"napkit" is required when you want to know position and
rotation of robots and other physical entities in your
application. It uses a webcam to detect ARToolKit markers.
"napkit" is distributed under GNU GPLv3.

Please see http://phybots.com/ for details.

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
http://phybots.com/
arc (at) digitalmuseum.jp