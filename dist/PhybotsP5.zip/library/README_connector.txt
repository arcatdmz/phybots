connector - a communication package for Windows/Mac/Linux
================================================================
Copyright (C) 2009-2013 Jun Kato

version 1.0.5
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

"connector" is a simple wrapper package for connecting Java VM
to external devices through TCP/IP, Serial and Parallel,
Bluetooth Serial Port Profile and LEGO Fantom API.

This library is distributed under MPL 1.1/GPL 2.0/LGPL 2.1
triple license. Please read LICENSE.txt for the detail.
You can get the source code by visiting its official site.

RXTXlib is used for Serial and Parallel connections. It is
developed at http://rxtx.qbang.org/wiki/ and distributed under
LGPL v 2.1 + Linking Over Controlled Interface.

BlueCove is used for bluetooth connection. It is developed at
http://bluecove.org/ and distributed under Apache License,
Version 2.0.

jfantom from LeJOS project is used for LEGO Fantom connection.
It is developed at http://lejos.sourceforge.net/ and
distributed under Mozilla Publiic License 1.0.

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
http://phybots.com/
arc (at) digitalmuseum.jp