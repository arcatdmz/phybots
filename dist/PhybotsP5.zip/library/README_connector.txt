connector - a communication package for Windows/Mac/Linux
Copyright (C) 2010 Jun KATO

version 1.0.4
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

"connector" is a simple wrapper package for connecting Java VM
to external devices through TCP/IP, Serial and Parallel,
Bluetooth Serial Port Profile.

This library is distributed under MPL 1.1/GPL 2.0/LGPL 2.1
triple license. Please read LICENSE.txt for the detail.
You can get the source code by visiting its official site.

RXTXlib is used for Serial and Parallel connections. It is
developed at http://rxtx.qbang.org/wiki/ and distributed under
LGPL v 2.1 + Linking Over Controlled Interface.

BlueCove is used for bluetooth connection. It is developed at
http://bluecove.org/ and distributed under Apache License,
Version 2.0.

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
http://phybots.com/
arc (at) digitalmuseum.jp