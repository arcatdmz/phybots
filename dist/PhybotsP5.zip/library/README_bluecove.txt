This directory contains deliverables of BlueCove JSR-82 project distributed under Apache License V2.0.
For more details, visit http://bluecove.org/