These marker patterns are generated with ARToolkit Patternmaker:
http://www.cs.utah.edu/gdc/projects/augmentedreality/