MQO loader
Copyright (C) 2009-2011 Jun KATO

version 1.0.0
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

"MQO loader" allows to load Metasequoia model file and render
the model for OpenGL. During development of this library,
kGLModel http://www.ric.hi-ho.ne.jp/keiweb/reader.html
based on GLMetaseq http://kougaku-navi.net/ARToolKit.html
was used for reference.
Official document of Metasequoia format can be found at
http://www.metaseq.net/metaseq/format.html

This library is part of "napkit" project, whose deliverables
are distributed under GNU GPLv3. Please read LICENSE.txt for
the license detail. You can get more information including the
source code by visiting its official site.

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
http://mr.digitalmuseum.jp/
arc (at) digitalmuseum.jp