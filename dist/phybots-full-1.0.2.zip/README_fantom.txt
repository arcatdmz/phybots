This directory contains deliverables of LeJOS project distributed under Mozilla Public License 1.0.
For more details, visit http://lejos.sourceforge.net/